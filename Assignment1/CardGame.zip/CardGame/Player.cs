﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame
{
    class Player : Game
    {
        public String pName;
        public int playerNumber;
        public String houseName = "House";
        public bool isHouse;
        public List<Card> tCard = new List<Card>();



        //default constructor
        public Player() { }


        //player constructor
        public Player(String plName, int plNumbers, List<Card>cardS, bool isH = false) : base(plName, plNumbers,cardS)
        {
            isHouse = isH;
            tCard = cardS;
            
        }

        //property
        public String setPlayerName
        {
            get { return playerName; }
            set { playerName = value; }
        }

        public int setPlayernumber
        {
            get { return playerNumber; }
            set
            {
                playerNumber = value;
            }
        }
        public List<Card> GetCards
        {
            get { return tCard; }
        }
        public String setHouseName
        {
            get { return houseName; }
        }

        //method         

        //检查是否是庄家
        public void checkIsHouse()
        {
            if (isHouse == false)
                isHouse = true;
            else
                isHouse = false;
        }

    }
}

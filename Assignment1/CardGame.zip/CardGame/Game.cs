﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CardGame
{
    class Game : Card
    {

        public bool isPlayerWin;
        public bool isHouseWin;
        public bool isVisiable;
        public String playerName;

        //数组记录玩牌人数最多为7
        public int playerNumbers;
        public int totalCardValue;
        public char str;

        public String temp;
        public List<Card> totalCard = new List<Card>();
        public List<Game> players = new List<Game>();




        //default constructor
        public Game() { }


        //game constructor
        public Game(String plName, int plNumbers, List<Card> cardS)
        {
            playerName = plName;
            playerNumbers = plNumbers;
            totalCard = cardS;

        }
        //Methods
        public String getPlayerName { get { return playerName; } }
        //开始游戏
        public void startGame(int totalPlayerNumber)
        {
            do
            {
                if (totalPlayerNumber <= 0 || totalPlayerNumber > 7)
                {
                    Console.Write("player number must between 1~7, How many players(1-7)?");
                    temp = Console.ReadLine();
                    totalPlayerNumber = int.Parse(temp);
                    continue;
                }
                for (int i = 0; i < totalPlayerNumber; i++)
                {
                    Player player = new Player();
                    Console.Write("Plese Enter the player name: ");
                    player.setPlayerName = Console.ReadLine();
                    player.setPlayernumber = i + 1;
                    var cards = player.dealCard();
                    player.totalCard.Add(cards);
                    players.Add(new Game(player.playerName, player.setPlayernumber, player.totalCard));
                }
                break;
            } while (true);
        }

        //发起始牌两张
        public Card dealCard()
        {
            Random random = new Random(Guid.NewGuid().GetHashCode());
            Deck deck = new Deck();

            deck.createDeck();
            deck.shuffle();


            //随机生成下标
            int cardIndexOne = random.Next(0, deck.allCard.Count);

            //实例化第一张随机牌
            Card cardOne = new Card
            {
                cardShape = deck.allCard[cardIndexOne].cardShape,
                cardValue = deck.allCard[cardIndexOne].cardValue
            };

            //删除卡组的这张牌
            deck.allCard.RemoveAt(cardIndexOne);
            return cardOne;
        }


        //翻庄家数值为10的牌
        public void flipOneCard()
        {
            //if 庄家牌面值==10
            //isVisable = True

            //else
            //isVisable = False

        }


        //发额外一张牌
        public void dealOnecard() { }


        //获得玩家牌面值
        public void getTotalValue() { }


        //判断牌面总值是否超过21点,然后判断输赢
        public void checkWin()
        {

            //if 庄家超过
            //没超过的玩家都赢
            //else
            //for each 玩家
            //if玩家没有超过21点的
            //if如果玩家牌总值大于庄家牌值
            //玩家赢
            //else if
            //玩家牌总值小于庄家
            //玩家赢
            //else
            //平局
            //else
            //玩家输

        }

    }
}

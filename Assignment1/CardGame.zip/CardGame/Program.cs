﻿using System;

namespace CardGame
{
    class Program
    {

        static void Main(string[] args)
        {

            String temp;
            int pNumber;

            Player player = new Player();
            Card card = new Card();
            Deck deckA = new Deck();
            Game game = new Game();



            Console.Write("Welcome to Blackjack");
            Console.Write("How many players(1-7)?");
            temp = Console.ReadLine();
            pNumber = int.Parse(temp);
            game.startGame(pNumber);




            foreach (var item in game.players)
            {
                foreach (var c in item.totalCard)
                {
                    Console.WriteLine(item.playerName + ": " + (int)c.cardValue + " " + (c.cardShape).ToString());
                }
            }

            // foreach (var item in game.players)
            // {
            //     Console.WriteLine(item.playerName + ": " + item.totalCard);
            // }






            // Console.WriteLine("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
            //deckA.createDeck();
            // foreach (var item in deckA.allCard)
            // {
            //     Console.WriteLine(item.cardValue);
            //     Console.WriteLine(item.cardShape);
            // }

            // Console.WriteLine("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            // deckA.shuffle();
            // foreach (var item in deckA.allCard)
            // {
            //     Console.WriteLine(item.cardShape);
            //     Console.WriteLine(item.cardShape);
            // }



            Console.ReadKey();
        }

    }
}
